CREATE TABLE `compsci316project`.`Artist` (
  `artistID` INT NOT NULL,
  `name` VARCHAR(50) NULL,
  PRIMARY KEY (`artistID`));

CREATE TABLE `compsci316project`.`Producer` (
  `producerID` INT NOT NULL,
  `name` VARCHAR(50) NULL,
  PRIMARY KEY (`producerID`));

CREATE TABLE `compsci316project`.`Writer` (
  `writerID` INT NOT NULL,
  `name` VARCHAR(50) NULL,
  PRIMARY KEY (`writerID`));

CREATE TABLE `compsci316project`.`Album` (
  `albumID` INT NOT NULL,
  `name` VARCHAR(50) NULL,
  `date_realeased` VARCHAR(45) NULL,
  `artist` INT NULL,
  PRIMARY KEY (`albumID`),
  INDEX `artist_idx` (`artist` ASC),
  CONSTRAINT `artist`
    FOREIGN KEY (`artist`)
    REFERENCES `compsci316project`.`Artist` (`artistID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

CREATE TABLE `compsci316project`.`Playlist` (
  `playlistID` INT NOT NULL,
  `name` VARCHAR(45) NULL,
  PRIMARY KEY (`playlistID`));

CREATE TABLE `compsci316project`.`Track` (
  `trackID` INT NOT NULL,
  `name` VARCHAR(45) NULL,
  `date_released` DATETIME NULL,
  `liveliness` FLOAT NULL,
  `tempo` FLOAT NULL,
  `variance` FLOAT NULL,
  `instrumentalness` FLOAT NULL,
  `acousticeness` FLOAT NULL,
  `speechiness` FLOAT NULL,
  `danceability` FLOAT NULL,
  `energy` FLOAT NULL,
  `loudness` FLOAT NULL,
  `artist` INT NULL,
  PRIMARY KEY (`trackID`),
  INDEX `artistidx_idx` (`artist` ASC),
  CONSTRAINT `artistidx`
    FOREIGN KEY (`artist`)
    REFERENCES `compsci316project`.`artist` (`artistID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);




CREATE TABLE `compsci316project`.`Contains` (
  `playlistID` INT NOT NULL,
  `trackID` INT NOT NULL,
  `order` INT NOT NULL,
  PRIMARY KEY (`playlistID`, `trackID`, `order`),
  INDEX `trackidx_idx` (`trackID` ASC),
  CONSTRAINT `playlistidx`
    FOREIGN KEY (`playlistID`)
    REFERENCES `compsci316project`.`Playlist` (`playlistID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `trackidx`
    FOREIGN KEY (`trackID`)
    REFERENCES `compsci316project`.`Track` (`trackID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

CREATE TABLE `compsci316project`.`Wrote` (
  `artistID` INT NOT NULL,
  `trackID` INT NOT NULL,
  PRIMARY KEY (`artistID`, `trackID`),
  INDEX `trackidx_idx` (`trackID` ASC),
  CONSTRAINT `trackidx`
    FOREIGN KEY (`trackID`)
    REFERENCES `compsci316project`.`Track` (`trackID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `artistidx`
    FOREIGN KEY (`artistID`)
    REFERENCES `compsci316project`.`Artist` (`artistID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

CREATE TABLE `compsci316project`.`Produced` (
  `producedID` INT NOT NULL,
  `trackID` INT NOT NULL,
  `Producedcol` VARCHAR(45) NULL,
  PRIMARY KEY (`producedID`, `trackID`),
  INDEX `trackidx_idx` (`trackID` ASC),
  CONSTRAINT `trackidx`
    FOREIGN KEY (`trackID`)
    REFERENCES `compsci316project`.`Track` (`trackID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `produceridx`
    FOREIGN KEY (`producedID`)
    REFERENCES `compsci316project`.`Producer` (`producerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

CREATE TABLE `compsci316project`.`Produced` (
  `producerID` INT NOT NULL,
  `trackID` INT NOT NULL,
  PRIMARY KEY (`artistID`, `producerID`),
  INDEX `trackidx_idx` (`trackID` ASC),
  CONSTRAINT `trackidx2`
    FOREIGN KEY (`trackID`)
    REFERENCES `compsci316project`.`Track` (`trackID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `producerIDx2`
    FOREIGN KEY (`producerID`)
    REFERENCES `compsci316project`.`Producer` (`producerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

CREATE TABLE `compsci316project`.`Wrote` (
  `writerID` INT NOT NULL,
  `trackID` INT NOT NULL,
  PRIMARY KEY (`writerID`, `trackID`),
  INDEX `trackidx3_idx` (`trackID` ASC),
  CONSTRAINT `writeridx`
    FOREIGN KEY (`writerID`)
    REFERENCES `compsci316project`.`Writer` (`writerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `trackidx3`
    FOREIGN KEY (`trackID`)
    REFERENCES `compsci316project`.`Track` (`trackID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

CREATE TABLE `compsci316project`.`onAlbum` (
  `albumID` INT NOT NULL,
  `trackID` INT NULL,
  PRIMARY KEY (`albumID`),
  INDEX `trackidx4_idx` (`trackID` ASC),
  CONSTRAINT `albumid2`
    FOREIGN KEY (`albumID`)
    REFERENCES `compsci316project`.`Album` (`albumID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `trackidx4`
    FOREIGN KEY (`trackID`)
    REFERENCES `compsci316project`.`Track` (`trackID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);



INSERT INTO `compsci316project`.`Artist` (`artistID`, `name`) VALUES ('1', 'artist1');
INSERT INTO `compsci316project`.`Artist` (`artistID`) VALUES ('2');

INSERT INTO `compsci316project`.`Album` (`albumID`, `name`, `date_realeased`, `artist`) VALUES ('1', 'album1', '1-1-1', '1');
INSERT INTO `compsci316project`.`Album` (`albumID`, `name`, `date_realeased`) VALUES ('2', 'album2', '2-2-2');

INSERT INTO `compsci316project`.`Playlist` (`playlistID`, `name`) VALUES ('1', 'playlist1');
INSERT INTO `compsci316project`.`Playlist` (`playlistID`, `name`) VALUES ('2', 'playlist2');

INSERT INTO `compsci316project`.`Producer` (`producerID`, `name`) VALUES ('1', 'producer1');
INSERT INTO `compsci316project`.`Producer` (`producerID`, `name`) VALUES ('2', 'producer2');

INSERT INTO `compsci316project`.`Writer` (`writerID`, `name`) VALUES ('1', 'writer1');
INSERT INTO `compsci316project`.`Writer` (`writerID`) VALUES ('2');

INSERT INTO `compsci316project`.`Track` (`trackID`, `name`, `date_released`, `liveliness`, `tempo`, `variance`, `instrumentalness`, `acousticeness`, `speechiness`, `danceability`, `energy`, `loudness`, `artist`) VALUES ('1', 'track1', '1-1-1', '0.1', '0.1', '0.1', '0.1', '0.1', '0.1', '0.1', '0.1', '0.1', '0.1');

INSERT INTO `compsci316project`.`Track` (`trackID`, `name`, `date_released`, `liveliness`, `tempo`, `variance`, `instrumentalness`, `acousticeness`, `speechiness`, `danceability`, `energy`, `loudness`, `artist`) VALUES ('2', 'track2', '2-2-2', '0.2', '0.2', '0.2', '0.2', '0.2', '0.2', '0.2', '0.2', '0.2', '2');

INSERT INTO `compsci316project`.`Contains` (`playlistID`, `trackID`, `order`) VALUES ('1', '1', '1');
INSERT INTO `compsci316project`.`Contains` (`playlistID`, `trackID`, `order`) VALUES ('2', '2', '1');

INSERT INTO `compsci316project`.`Produced` (`producerID`, `trackID`) VALUES ('1', '1');
INSERT INTO `compsci316project`.`Produced` (`producerID`, `trackID`) VALUES ('2', '2');

INSERT INTO `compsci316project`.`Wrote` (`writerID`, `trackID`) VALUES ('1', '1');
INSERT INTO `compsci316project`.`Wrote` (`writerID`, `trackID`) VALUES ('2', '2');
