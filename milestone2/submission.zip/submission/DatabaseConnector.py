import mysql.connector
import ConfigReader

class DatabaseConnector:


    def __init__(self):
        """initializes the database connector given in the config file """
        self.generateConnection()

    def generateConnection(self):
        """generates a connection object to a server given in the config file """
        config = ConfigReader.ConfigReader()
        self.connection = mysql.connector.connect(
            user = config.getUser(),
            password = config.getPassword(),
            host = config.getHost(),
            database = config.getDatabase()
        )
        self.cursor = self.connection.cursor()
        return self.cursor

    def insertSong(self, map, songID, artistID):
        self.cursor.execute(sql)

    def insertArtist(self, artist, artistID):
        self.cursor.execute("INSERT INTO Artist (artistID, name) VALUES (%s, %s);", (artistID, artist))
        self.connection.commit()


    def close(self):
        self.connection.close()
