# How to Use

Generate the production database by running Main.py (python3)

## Purpose
This directory is used to translate information from the Spotify API to our production Database (currently located on Riley's computer)

## Structure

### Main.py
This class is run to begin translating data from the Spotify API to our production database 

### DatabaseConnector.py
This class is responsible for the connection to our production database

### SpotifyConnector.py
This class is responsible for the connection to the Spotify API

### ConfigReader.py
This class is responisble for reading in config vars from a *config.ini* file 