import csv

class SpotifyConnector:
    """Connects the application to the spotify API """
    def __init__(self):
        self.map = {}
        with open('dataTranslator/SpotifyAudioFeaturesApril2019.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                if line_count == 0:
                    attributes = row
                else:
                    self.map[row[1]] = row
                line_count += 1
            print(attributes)

    def getDataMap(self):
        return self.map        