import DatabaseConnector
import SpotifyConnector
#runs the main code
if __name__ == "__main__":
    db = DatabaseConnector.DatabaseConnector()
    conn = SpotifyConnector.SpotifyConnector()
    dataMap = conn.getDataMap()
    id = 0
    added = {}
    for key in dataMap:
        if(dataMap[key][0] not in added):          
            added[dataMap[key][0]] = id
            try:
                db.insertArtist(dataMap[key][0], id)
            except:
                print("couldnt insert: " + dataMap[key][0])
            id+=1
        db.insertSong(dataMap[key], id)

    db.close()
    